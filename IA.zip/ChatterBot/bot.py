from chatterbot.trainers import ListTrainer
from chatterbot import ChatBot
bot = ChatBot('Test')
conversa = ['Oi', 'Olá', 'Como vai?', 'Bem', 'Qual o seu nome?', 'Anderson', 'Qual seu filme favorito?' , 'V de vingança', 'Bom dia', 'Bom dia', 'Boa Noite', 'Boa Noite', 'Beibe Beibe do Beibe do Biruleibe Leibe?', 'Vai se foder']
bot.set_trainer(ListTrainer)
bot.train(conversa)
while True:
	quest = input("Você: ")
	resposta = bot.get_response(quest)
	print ("Bot:", resposta)
